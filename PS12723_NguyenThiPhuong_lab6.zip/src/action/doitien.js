import { DOI_TIEN } from '../const'
export const actDoiTien =(doitien) =>{
    return{
        type: DOI_TIEN,
        doitien
    }
}