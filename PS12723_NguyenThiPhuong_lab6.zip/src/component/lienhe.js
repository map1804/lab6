import { Component } from "react";
class Lienhe extends Component{
    render(){
        return(
            <div>day la Lienhe</div>
        )
    }
}
export default Lienhe